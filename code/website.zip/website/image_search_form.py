import web
import os
import random
import time

render = web.template.render('templates/')
urls = (
    '/', 'index',
    '/img/(.*)', 'images',
    '/search', 'ImageSearch',
)

class index:
    def GET(self):
        input = web.input(query=None)
        query = input.query
        resp = {'query':input.query, 'content':[]}

        if query is None:
            subset = random.sample(web.imset, 50)
            hitlist = [{'id':x} for x in subset]
        else:
            s_time = time.time()
            datafile = os.path.join('flickr10k', '%s.txt' % query)
            imset = map(str.strip, open(datafile).readlines())
            hitlist = [{'id':x} for x in imset]
            timecost = time.time() - s_time
            resp['time'] = timecost
        resp['content'] = hitlist
        return render.search_form(resp)


class images:

    def GET(self, name):
        imageid, ext = name.split('.')
        imfile = os.path.join(web.data_dir, 'ImageData', imageid[-1], name)
        try:
            web.header("Content-Type", "images/jpeg") # Set the Header
            return open(imfile,"rb").read() # Notice 'rb' for reading images
        except:
            raise web.notfound()          


class ImageSearch:
    def POST(self):
        input = web.input()
        raise web.seeother('/?query=%s' % input.query)

if __name__ == "__main__":
    app = web.application(urls, globals())
    data_dir = os.path.join(os.environ['HOME'], 'VisualSearch', 'flickr10k')
    imset_file = os.path.join(data_dir, 'ImageSets', 'flickr10k.txt')
    web.imset = map(str.strip, open(imset_file).readlines())
    web.data_dir = data_dir
    app.run()

