import web
import os
import random


render = web.template.render('templates/')
urls = (
    '/', 'index',
    '/img/(.*)', 'images',
)

class index:
    def GET(self):
        input = web.input(tag=None)
        resp = {'content':[]}
        if input.tag is None:
            subset = random.sample(web.imset, 50)
            hitlist = [{'id':x} for x in subset]
        resp['content'] = hitlist
        return render.images(resp)


class images:

    def GET(self, name):
        imageid, ext = name.split('.')
        imfile = os.path.join(web.data_dir, 'ImageData', imageid[-1], name)
        try:
            web.header("Content-Type", "images/jpeg") # Set the Header
            return open(imfile,"rb").read() # Notice 'rb' for reading images
        except:
            raise web.notfound()          

if __name__ == "__main__":
    app = web.application(urls, globals())
    data_dir = os.path.join(os.environ['HOME'], 'VisualSearch', 'flickr10k')
    imset_file = os.path.join(data_dir, 'ImageSets', 'flickr10k.txt')
    web.imset = map(str.strip, open(imset_file).readlines())
    web.data_dir = data_dir
    app.run()

