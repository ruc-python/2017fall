
import os

tagfile = os.path.join(os.environ['HOME'], 'VisualSearch', 'flickr10k', 'TextData', 'id.userid.rawtags.txt')
index_dir = 'flickr10k'

mini_count = 50
tag2imlist = {}

for line in open(tagfile):
    image, user, tags = line.strip().split('\t')
    tagset = set(tags.split())
    for tag in tagset:
        tag2imlist.setdefault(tag, []).append(image)
    
vocab = [tag for (tag,imlist) in tag2imlist.iteritems() if len(imlist)>=mini_count]
print 'vocab %d' % len(vocab)

for tag in vocab:
    resfile = os.path.join(index_dir, '%s.txt' % tag)
    imlist = tag2imlist[tag]
    fw = open(resfile, 'w')
    fw.write('\n'.join(imlist))
    fw.close()

